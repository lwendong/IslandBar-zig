# IslandBar 渐进重构：阶段 0 静态基线

> 快照日期：2026-10-15  
> 来源：用户提供的 `res.zip`（SHA-256: `79906ef073b56f564affb9c069564679df4cbe98868d1a5b8da3fdc7e08d9c3e`）  
> 设计依据：`docs/IslandBar-Architecture-V1.md`（目标架构，状态仍为 PROPOSED）  
> 验证级别：**离线静态检查通过；Windows 构建与交互尚未验证。**

## 当前工程范围

- 现有工程包含 41 个 `src/**/*.zig` 源码文件，约 24,755 行；`build.zig` 注册了 40 个命名源码模块。
- `src/app/main.zig` 约 3,991 行，混合入口、`PaintContext`、窗口绘制回调、Sound UI 文案构造、点击处理、系统操作。
- `src/ui/Renderer.zig` 约 1,503 行；`src/ui/TextRenderer.zig` 约 2,493 行，均存在具体 Feature 依赖。
- `src/features/SoundOutput.zig` 与 `src/features/NotificationIcon.zig` 使用 `MusicSession.fetchAppIconForTest`，形成跨 Feature 实现耦合。
- `src/platform/windows/SystemToggles.zig` 直接导入 `StartMenu`；`src/platform/windows/NotificationPipe.zig` 直接导入 `Notification`。
- `src/ui/Renderer.zig` 中 `nextCardOwner` 判断卡片显示优先级，主入口调用它；按目标架构，此策略最终应归 Shell。
- `src/core/CardLayout.zig`、`src/core/TaskStripLayout.zig` 等仍承担具体页面布局职责。此类**职责错误**不能仅用 import 扫描脚本发现，需要后续人工/实机检查。

## 依赖边界基线

`tools/architecture/check_boundaries.py` 使用 `build.zig` 中现有命名模块映射，扫描 Zig 文件的 `@import("...")`。

当前基线为 **21 条旧跨层依赖**，详见 `tools/architecture/legacy-dependencies.json`。这个数字只是脚本规则下的**静态依赖边**，不是已证实的 21 个运行时 bug，也不是完整的架构问题数量。

默认执行时：旧依赖继续允许，新增违例返回非零错误码；旧依赖删除后会提示已消除。**不要通过修改白名单掩盖新依赖。** 基线更新必须在变更审查后显式执行 `--record-baseline`。

脚本检测不到 Zig `extern` 调用、运行时全局变量、通过参数传递的资源所有权和 UI 命中公式重复等问题；它也不判断代码实际是否有缺陷。

## 尚待记录的 Windows 实机基线

在 Windows 构建机上执行并将实际结果写入 `AGENTS.md`：

1. `zig version`；核对 `START-HERE.txt` 所称 Zig 0.17 是否与本机一致（文件所述版本尚未通过本轮命令验证）。
2. `zig build`；记录返回码、输出产物路径、错误原文。
3. `zig build setup-build`；确认安装器构建仍可用，**不要自动运行安装或修改系统任务栏设置**。
4. `zig build native-smoke-build`、`zig build thumbprobe-build`、`zig build sysstatusprobe-build`、`zig build geoprobe-build`、`zig build gsmtcprobe-build`；仅先编译，不强制运行可能修改系统状态的 probe。
5. `python tools/architecture/check_boundaries.py --report`；如果 Python 不可用，记录环境缺口，不影响主程序编译。
6. 手动记录收起/悬停/展开、音乐、声音、通知、托盘、启动菜单、任务按钮、动画中点击、DPI/多屏的**实际**行为；屏幕截图要明确版本和复现步骤。
7. 分别记录 `zig-out/bin/IslandBar.exe` 与 `zig-out/bin/IslandBarSetup.exe` 的产物是否由本轮构建生成；压缩包中的既有二进制文件不能充当本轮编译验证。

## 已知环境与材料缺口

- 本轮离线分析环境没有 `zig` 可执行文件，也无法进行 Win32 GUI 实机回归；因此 **未证明现有源代码可编译、可运行**。
- `START-HERE.txt` 指向 `README.md` 与 `TESTING.md`，但两者不在本轮 `res.zip` 中；请在实际工作目录核对，不要擅自虚构内容。
- `res.zip` 内带有以前的 `zig-out` 产物和日志。日志仅能反映先前运行，不等于本轮状态。
- 初始独立提供的 `AGENTS.md` 内容仅为 `111`，没有有效可追溯进度。本阶段将其替换为结构化记录，后续 Codex 每次改动都应追加更新。

## 阶段 0 范围和下一步

本阶段**不改动生产 Zig 源码、运行行为、UI、安装器与 build.zig**。只增加依赖审计和重构记录。完成 Windows 构建/人工基线后进入阶段 1：确定 State/Action/Service Contract 的权威归属，再考虑首次纯策略提取；不直接开始整仓移动。

后续高价值试点：SoundPage 的完整 Feature/UI/Windows Audio 边界（架构文档阶段 3 建议）。首次功能迁移前需先打通 Shell 展示边界和同帧 LayoutSnapshot 设计。
